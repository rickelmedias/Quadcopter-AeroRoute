# Computador de missão (Raspberry Pi Zero W)

Instalado de DroneSTM32 (branch comunicacao-pi-stm32) por tools/pi/deploy.sh.
Não editar aqui: mudar no repositório e rodar o deploy de novo.

- ~/drone/dronectl            atalho do dronectl (venv ~/drone-venv)
- tools/pi/dronectl/          código (link DroneLink, missão, rotas)
- tools/pi/missoes/           arquivos de missão e pontos.txt (quadrado de 40 cm)
- protocol/drone_controller.xml   dialeto MAVLink (gera o módulo Python)
- ~/backup/drone-antigo-2026-11-07.tar.gz   projeto anterior (dronelinkd), arquivado

Uso:
    ~/drone/dronectl status
    ~/drone/dronectl missao --sim                                   # shell: takeoff 30, route, land
    ~/drone/dronectl missao --sim tools/pi/missoes/quadrado_40cm.txt
    cd ~/drone/tools/pi && ~/drone-venv/bin/python -m unittest discover -s tests
